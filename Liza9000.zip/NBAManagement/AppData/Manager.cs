﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NBAManagement.AppData
{
    public class Manager
    {
        public static Team CheckTeam { get; set; }
        public static AdminLogin WindowAdminLogin { get; set; }
        public static ManageMatchups WindowManageMatchups { get; set; }
        public static bool LoginRemember { get; set; } = false;
        public static string Login {  get; set; }
        public static string Password { get; set; }
        public static int UserRoleId { get; set; }
        public static bool AutorisationCheck { get; set; } = false;
        public static string CurrentMatchupType { get; set; } = "Regular Season";
        public static bool TotalCheckPoints { get; set; } = false;
    }
}