﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using NBAManagement.AppData;

namespace NBAManagement
{
    /// <summary>
    /// Логика взаимодействия для PlayersMain.xaml
    /// </summary>
    public partial class PlayersMain : Window
    {
        private static int pageIndex = 0;
        private List <Player> targetPlayersList = BasketballSystemEntities.GetContext().Player.ToList();
        private float pageCount = 0;

        private string currentTextPosition;
        private string currentTeamName;
        private string currentYearPeriod;

        private string textFirstYear;
        private string textLastYear;

        private int currentYearFirst;
        private int currentYearLast;
        public PlayersMain()
        {
            InitializeComponent();

            List<string> seasonList = new List<string>();
            seasonList.Add("All Seasons");
            foreach (var seas in BasketballSystemEntities.GetContext().Season)
            {
                seasonList.Add(seas.Name);
            }

            choseYearCheck.ItemsSource = seasonList;

            choseTeamCheck.Items.Insert(0, "All Teams");
            foreach (var team in BasketballSystemEntities.GetContext().Team)
            {
                choseTeamCheck.Items.Add(team.TeamName);
            }
            PageUpdate();

            int yearToday = DateTime.Now.Year;
            if (yearToday % 2 == 0)
            {
                historyText.Text += yearToday - 1 + "-" + yearToday + "," +
                    " and the NBA already has a history of " + (yearToday - 1946) + " years.";
            }
            else
            {
                historyText.Text += yearToday + "-" + yearToday + 1 + "," +
                    " and the NBA already has a history of " + (yearToday - 1946) + " years.";
            }
        }

        private void ButtonSearchUpperClick(object sender, RoutedEventArgs e)
        {
            currentTextPosition = Convert.ToString((sender as Button).Content);
            if (currentTextPosition == "ALL")
            {
                targetPlayersList = BasketballSystemEntities.GetContext().Player.ToList();
            }
            else if (currentTextPosition != null)
            {
                targetPlayersList = BasketballSystemEntities.GetContext().Player.Where(p => p.Name.ToUpper().StartsWith(currentTextPosition)).OrderBy(p => p.PlayerId).ToList();
            }
            pageIndex = 0;
            PageUpdate();
        }

        private void ButtonBackClick(object sender, RoutedEventArgs e)
        {
            VisitorMenu visitorChangeWindow = new VisitorMenu();
            visitorChangeWindow.Show();
            this.Close();
        }

        private void PageUpdate()
        {
            var currentPlayers = new List<Player>();
            foreach (var pos in targetPlayersList)
            {
                currentPlayers.Add(pos);
            }

            if (currentYearPeriod != null && currentYearPeriod != "ALL" && currentYearFirst != 0)
            {
                var playInTeamsList = BasketballSystemEntities.GetContext().PlayerInTeam.ToList();
                var matchupsList = BasketballSystemEntities.GetContext().Matchup.Where(p => p.SeasonId == choseYearCheck.SelectedIndex).ToList();
                playInTeamsList = playInTeamsList.Where(p => matchupsList.Any(c => c.Team_Away == p.TeamId || c.Team_Home == p.TeamId)).ToList();
                currentPlayers = currentPlayers.Where(p => playInTeamsList.Any(c => c.PlayerId == p.PlayerId) && p.JoinYear.Year <= currentYearLast).ToList();
            }

            if (currentTeamName != null && currentTeamName != "ALL")
            {
                var keyTeamPos = BasketballSystemEntities.GetContext().Team.Where(p => p.TeamName == currentTeamName).First();
                var checkTeamPlayers = BasketballSystemEntities.GetContext().PlayerInTeam.Where(p => p.TeamId == keyTeamPos.TeamId).ToList();
                currentPlayers = currentPlayers.Where(p => checkTeamPlayers.Any(c => c.PlayerId == p.PlayerId)).ToList();
            }

            currentPlayers = currentPlayers.Where(p => p.Name.ToLower().Contains(inputPlayerCheck.Text.ToLower())).ToList();

            dateGridPlayers.ItemsSource = currentPlayers.OrderBy(p => p.PlayerId).Skip(pageIndex).Take(10).ToList();
            targetPageBox.Text = Convert.ToString(pageIndex / 10 + 1);

            textRecords.Text = "Total " + currentPlayers.Count().ToString() + " records, "
            + dateGridPlayers.ItemsSource.Cast<Player>().Count() + " records in one page";

            pageCount = currentPlayers.Count() / 10;
            if (pageCount - (int)pageCount > 0)
                pageCount++;

            if (currentPlayers.Count() % 10 == 0)
            {
                statusPageList.Text = "of " + pageCount;
            }
            else
            {
                statusPageList.Text = "of " + (pageCount + 1);
            }
        }

        private void ButtonFirstPageClick(object sender, RoutedEventArgs e)
        {
            pageIndex = 0;
            PageUpdate();
        }

        private void ButtonLastPageClick(object sender, RoutedEventArgs e)
        {
            if (targetPlayersList.Count() % 10 != 0)
            {
                pageIndex = targetPlayersList.Count() - (targetPlayersList.Count() % 10);
            }
            else
            {
                pageIndex = targetPlayersList.Count() - 10;
            }
            PageUpdate();
        }

        private void ButtonTenNextPageClick(object sender, RoutedEventArgs e)
        {
            if (pageIndex < targetPlayersList.Count()-10)
            {
                pageIndex = pageIndex + 10;
                PageUpdate();
            }
        }

        private void ButtonTenBackClick(object sender, RoutedEventArgs e)
        {
            if(pageIndex >= 10)
            {
                pageIndex = pageIndex - 10;
                PageUpdate();
            }
        }

        private void UpdatePlayers()
        {
            if (choseYearCheck.SelectedIndex == 0)
            {
                currentYearPeriod = "ALL";
            }
            else if (choseYearCheck.SelectedIndex > 0)
            {
                currentYearPeriod = Convert.ToString(choseYearCheck.SelectedItem);

                textFirstYear = "";
                textLastYear = "";

                for (int i = 0; i < 4; i++)
                {
                    textFirstYear = textFirstYear + currentYearPeriod[i];
                    textLastYear = textLastYear + currentYearPeriod[i+5]; 
                }

                currentYearFirst = Convert.ToInt32(textFirstYear);
                currentYearLast = Convert.ToInt32(textLastYear);
            }

            if (choseTeamCheck.SelectedIndex == 0)
            {
                currentTeamName = "ALL";
            }
            else if (choseTeamCheck.SelectedIndex > 0)
            {
                currentTeamName = Convert.ToString(choseTeamCheck.SelectedItem);
            }

            pageIndex = 0;
            PageUpdate();
        }

        private void ChoseTeamCheckSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdatePlayers();
        }

        private void InputPlayerCheckTextChanged(object sender, TextChangedEventArgs e)
        {
            UpdatePlayers();
        }

        private void ChoseYearCheckSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdatePlayers();
        }
    }
}