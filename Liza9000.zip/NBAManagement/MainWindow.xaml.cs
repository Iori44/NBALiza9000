﻿using NBAManagement.AppData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace NBAManagement
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private static int firstImageTarget = 16;
        private static int secondImageTarget = 17;
        private static int thirdImageTarget = 18;
        public MainWindow()
        {
            InitializeComponent();
            int yearToday = DateTime.Now.Year;
            if (yearToday % 2 == 0)
            {
                historyText.Text += yearToday-1 + "-" + yearToday + "," +
                    " and the NBA already has a history of " + (yearToday-1946) + " years.";
            }
            else
            {
                historyText.Text += yearToday + "-" + yearToday+1 + "," +
                    " and the NBA already has a history of " + (yearToday - 1946) + " years.";
            }
        }

        private void ButtonAdminClick(object sender, RoutedEventArgs e)
        {
            if (Manager.AutorisationCheck == true && Manager.LoginRemember == true)
            {
                switch (Manager.UserRoleId)
                {
                    case 1:
                        EventAdministratorMenu eventAdministratorMenu = new EventAdministratorMenu();
                        eventAdministratorMenu.Show();
                        this.Close();
                        break;
                    case 2:
                        TechnicalAdministratorMenu technicalAdministratorMenu = new TechnicalAdministratorMenu();
                        technicalAdministratorMenu.Show();
                        this.Close();
                        break;
                }
            }
            else
            {
                AdminLogin adminChangeWindow = new AdminLogin();
                adminChangeWindow.Show();
                this.Close();
            }
        }

        private void ButtonVisitorClick(object sender, RoutedEventArgs e)
        {
            VisitorMenu visitorChangeWindow = new VisitorMenu();
            visitorChangeWindow.Show();
            this.Close();
        }

        private void ForwardImgClick(object sender, RoutedEventArgs e)
        {
            if (firstImageTarget < 16)
            {
                firstImageTarget = firstImageTarget + 3;
                secondImageTarget = secondImageTarget + 3;
                thirdImageTarget = thirdImageTarget + 3;
            }

            firstImg.Source = new BitmapImage(new Uri("/Resources/Pictures/" + firstImageTarget + ".jpg", UriKind.Relative));
            secondImg.Source = new BitmapImage(new Uri("/Resources/Pictures/" + secondImageTarget + ".jpg", UriKind.Relative));
            thirdImg.Source = new BitmapImage(new Uri("/Resources/Pictures/" + thirdImageTarget + ".jpg", UriKind.Relative));
        }

        private void BackImgClick(object sender, RoutedEventArgs e)
        {
            if (firstImageTarget > 1)
            {
                firstImageTarget = firstImageTarget - 3;
                secondImageTarget = secondImageTarget - 3;
                thirdImageTarget = thirdImageTarget - 3;
            }

            firstImg.Source = new BitmapImage(new Uri("/Resources/Pictures/" + firstImageTarget + ".jpg",UriKind.Relative));
            secondImg.Source = new BitmapImage(new Uri("/Resources/Pictures/" + secondImageTarget +".jpg", UriKind.Relative));
            thirdImg.Source = new BitmapImage(new Uri("/Resources/Pictures/" + thirdImageTarget + ".jpg", UriKind.Relative));
        }
    }
}