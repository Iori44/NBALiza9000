﻿using NBAManagement.AppData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NBAManagement
{
    /// <summary>
    /// Логика взаимодействия для AddNewMatchupForRegularSeason.xaml
    /// </summary>
    public partial class AddNewMatchupForRegularSeason : Window
    {
        private Matchup currentMatchup = new Matchup();
        private string firstYear = "";
        private string lastYear = "";
        public AddNewMatchupForRegularSeason(Matchup selectedMatchup)
        {
            InitializeComponent();
            List<string> seasonList = new List<string>();
            foreach (var seas in BasketballSystemEntities.GetContext().Season)
            {
                seasonList.Add(seas.Name);
            }

            firstYear = "";
            lastYear = "";
            for (int i = 0; i < 4; i++)
            {
                firstYear = firstYear + seasonList.Last()[i];
                lastYear = lastYear + seasonList.Last()[i+5];
            }
            DateTime yearOne = new DateTime(Convert.ToInt32(firstYear), 1, 1);
            DateTime yearTwo = new DateTime(Convert.ToInt32(lastYear), 12, 31);
            choseCurrentDate.DisplayDateStart = Convert.ToDateTime(yearOne);
            choseCurrentDate.DisplayDateEnd = Convert.ToDateTime(yearTwo);

            inputCurrentSeason.Text = seasonList.Last();

            choseTeamAway.ItemsSource = BasketballSystemEntities.GetContext().Team.ToList();
            choseTeamHome.ItemsSource = BasketballSystemEntities.GetContext().Team.ToList();

            if (selectedMatchup != null)
            {
                currentMatchup = selectedMatchup;
                var currentSeason = BasketballSystemEntities.GetContext().Season.Where(p => p.SeasonId == currentMatchup.SeasonId).First();
                inputCurrentSeason.Text = currentSeason.Name;

                var currentMatchupType = BasketballSystemEntities.GetContext().MatchupType.Where(p => p.MatchupTypeId == currentMatchup.MatchupTypeId).First();
                inputCurrentType.Text = currentMatchupType.Name;

                DateTime targetDate = currentMatchup.Starttime;
                choseCurrentDate.SelectedDate = targetDate.Date;

                if (currentMatchup.Starttime.Hour < 10)
                {
                    inputCurrentTime.Text = "0" + currentMatchup.Starttime.Hour + ":";
                }
                else
                {
                    inputCurrentTime.Text = currentMatchup.Starttime.Hour + ":";
                }
                if (currentMatchup.Starttime.Minute < 10)
                {
                    inputCurrentTime.Text = inputCurrentTime.Text + "0" + currentMatchup.Starttime.Minute;
                }
                else
                {
                    inputCurrentTime.Text = inputCurrentTime.Text + currentMatchup.Starttime.Minute;
                }

                var teamsCheckAway = BasketballSystemEntities.GetContext().Team.Where(p => p.TeamId == currentMatchup.Team_Away).First();
                var teamsCheckHome = BasketballSystemEntities.GetContext().Team.Where(p => p.TeamId == currentMatchup.Team_Home).First();
                choseTeamAway.SelectedIndex = teamsCheckAway.TeamId-1;
                choseTeamHome.SelectedIndex = teamsCheckHome.TeamId-1;
            }
               
            DataContext = currentMatchup;

            int yearToday = DateTime.Now.Year;
            if (yearToday % 2 == 0)
            {
                historyText.Text += yearToday - 1 + "-" + yearToday + "," +
                    " and the NBA already has a history of " + (yearToday - 1946) + " years.";
            }
            else
            {
                historyText.Text += yearToday + "-" + yearToday + 1 + "," +
                    " and the NBA already has a history of " + (yearToday - 1946) + " years.";
            }
        }

        private void ButtonLogoutClick(object sender, RoutedEventArgs e)
        {
            Manager.AutorisationCheck = false;
            Manager.LoginRemember = false;
            Manager.UserRoleId = 0;
            Manager.Login = "";
            Manager.Password = "";
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Manager.WindowManageMatchups.Close();
            this.Close();
        }

        private void ButtonBackClick(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void ButtonSaveClick(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();
            bool errorCheckText = false;

            string hours = "";
            string minutes = "";

            if (String.IsNullOrEmpty(choseCurrentDate.Text))
            {
                errors.AppendLine("Необходимо указать дату!");
            }
            else if (Convert.ToDateTime(choseCurrentDate.Text).Year < Convert.ToInt32(firstYear) 
                || (Convert.ToDateTime(choseCurrentDate.Text).Year > Convert.ToInt32(lastYear)))
            {
                errors.AppendLine($"Нельзя выходит за рамки {firstYear}-{lastYear} годов!");
            }

            if (String.IsNullOrEmpty(inputCurrentTime.Text))
            {
                errors.AppendLine("Необходимо указать время!");
                errorCheckText = true;
            }
            else
            {
                for (int i = 0; i < inputCurrentTime.Text.Length; i++)
                {
                    if (i < 2 || i > 2)
                    {
                        if (!Char.IsDigit(inputCurrentTime.Text[i]))
                        {
                            errors.Append("Время должно быть заполнено по формату 00:00 !");
                            errorCheckText = true;
                            break;
                        }
                    }
                    else if (i == 2)
                    {
                        if (inputCurrentTime.Text[i] != ':')
                        {
                            errors.Append("Время должно быть заполнено по формату 00:00 !");
                            errorCheckText = true;
                            break;
                        }
                    }
                }
                               
                if (errorCheckText == false)
                {
                    for (int i = 0; i < inputCurrentTime.Text.Length; i++)
                    {
                        if (i <= 1)
                        {
                            hours += inputCurrentTime.Text[i];
                        }
                        if (i > 2)
                        {
                            minutes += inputCurrentTime.Text[i];
                        }
                    }
                }

                if (errorCheckText == false && (Convert.ToInt32(hours) > 23 || Convert.ToInt32(minutes) > 59))
                {
                    errors.Append("Количество часов не может превышать 23, а минут 59 !");
                }
            }

            if (choseTeamAway.SelectedIndex == -1 || choseTeamHome.SelectedIndex == -1)
            {
                errors.Append("Необходимо выбрать обе команды!");
            }
            else if (choseTeamAway.SelectedIndex == choseTeamHome.SelectedIndex && choseTeamAway.SelectedIndex > -1)
            {
                errors.Append("Нельзя указать одинаковые команды, выберите разные!");
            }

            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }
            else
            {
                var seasonList = BasketballSystemEntities.GetContext().Season.Where(p => p.Name == inputCurrentSeason.Text).First();
                currentMatchup.SeasonId = seasonList.SeasonId;
                var typesList = BasketballSystemEntities.GetContext().MatchupType.Where(p => p.Name == inputCurrentType.Text).First();
                currentMatchup.MatchupTypeId = typesList.MatchupTypeId;
                var teamAway = BasketballSystemEntities.GetContext().Team.Where(p => p.TeamName == choseTeamAway.Text).First();
                var teamHome = BasketballSystemEntities.GetContext().Team.Where(p => p.TeamName == choseTeamHome.Text).First();
                currentMatchup.Team_Away = teamAway.TeamId;
                currentMatchup.Team_Home = teamHome.TeamId;
                if (!String.IsNullOrEmpty(inputCurrentLocation.Text))
                {
                    currentMatchup.Location = inputCurrentLocation.Text;
                }

                DateTime dateTarget = new DateTime(choseCurrentDate.DisplayDate.Year, choseCurrentDate.DisplayDate.Month, choseCurrentDate.DisplayDate.Day, Convert.ToInt32(hours), Convert.ToInt32(minutes),0);
                
                currentMatchup.Starttime = dateTarget;

                currentMatchup.Team_Away_Score = 0;
                currentMatchup.Team_Home_Score = 0;
                currentMatchup.Status = -1;
                currentMatchup.CurrentQuarter = "00:00-4th";

                if (currentMatchup.MatchupId == 0)
                    BasketballSystemEntities.GetContext().Matchup.Add(currentMatchup);

                try
                {
                    BasketballSystemEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные успешно сохранены!");
                    Manager.WindowManageMatchups.dateGridRegular.ItemsSource = BasketballSystemEntities.GetContext().Matchup.Where(p => p.MatchupTypeId == 1).ToList();
                    Manager.WindowManageMatchups.dateGridPres.ItemsSource = BasketballSystemEntities.GetContext().Matchup.Where(p => p.MatchupTypeId == 0).ToList();
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }

            }
        }

    }
}