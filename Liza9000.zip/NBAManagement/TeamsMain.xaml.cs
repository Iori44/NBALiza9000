﻿using NBAManagement.AppData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NBAManagement
{
    /// <summary>
    /// Логика взаимодействия для TeamsMain.xaml
    /// </summary>
    public partial class TeamsMain : Window
    {
        public TeamsMain()
        {
            InitializeComponent();
            int yearToday = DateTime.Now.Year;
            if (yearToday % 2 == 0)
            {
                historyText.Text += yearToday - 1 + "-" + yearToday + "," +
                    " and the NBA already has a history of " + (yearToday - 1946) + " years.";
            }
            else
            {
                historyText.Text += yearToday + "-" + yearToday + 1 + "," +
                    " and the NBA already has a history of " + (yearToday - 1946) + " years.";
            }


            listEastAtlant.ItemsSource = BasketballSystemEntities.GetContext().Team.Where(p => p.DivisionId == 3).ToList();
            listEastCentral.ItemsSource = BasketballSystemEntities.GetContext().Team.Where(p => p.DivisionId == 2).ToList();
            listEastSouth.ItemsSource = BasketballSystemEntities.GetContext().Team.Where(p => p.DivisionId == 1).ToList();

            listWestNorth.ItemsSource = BasketballSystemEntities.GetContext().Team.Where(p => p.DivisionId == 5).ToList();
            listWestPacif.ItemsSource = BasketballSystemEntities.GetContext().Team.Where(p => p.DivisionId == 6).ToList();
            listWestSouth.ItemsSource = BasketballSystemEntities.GetContext().Team.Where(p => p.DivisionId == 4).ToList();
        }

        private void ButtonBackClick(object sender, RoutedEventArgs e)
        {
            VisitorMenu visitorChangeWindow = new VisitorMenu();
            visitorChangeWindow.Show();
            this.Close();
        }

        private void ButtonRosterClick(object sender, RoutedEventArgs e)
        {
            TeamDetail teamDetailChange = new TeamDetail((sender as Button).DataContext as Team, 0);
            teamDetailChange.Show();
            this.Close();
        }

        private void ButtonMatchupClick(object sender, RoutedEventArgs e)
        {
            TeamDetail teamDetailChange = new TeamDetail((sender as Button).DataContext as Team, 1);
            teamDetailChange.Show();
            this.Close();
        }

        private void ButtonFirstLineupClick(object sender, RoutedEventArgs e)
        {
            TeamDetail teamDetailChange = new TeamDetail((sender as Button).DataContext as Team, 2);
            teamDetailChange.Show();
            this.Close();
        }
    }
}
