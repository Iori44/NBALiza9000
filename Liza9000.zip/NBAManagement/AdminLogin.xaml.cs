﻿using NBAManagement.AppData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NBAManagement
{
    /// <summary>
    /// Логика взаимодействия для AdminLogin.xaml
    /// </summary>
    public partial class AdminLogin : Window
    {
        public AdminLogin()
        {
            InitializeComponent();
            Manager.WindowAdminLogin = this;
            
            int yearToday = DateTime.Now.Year;
            if (yearToday % 2 == 0)
            {
                historyText.Text += yearToday - 1 + "-" + yearToday + "," +
                    " and the NBA already has a history of " + (yearToday - 1946) + " years.";
            }
            else
            {
                historyText.Text += yearToday + "-" + yearToday + 1 + "," +
                    " and the NBA already has a history of " + (yearToday - 1946) + " years.";
            }
        }

        private void ButtonBackClick(object sender, RoutedEventArgs e)
        {
            MainWindow mainChangeWindow = new MainWindow();
            mainChangeWindow.Show();
            this.Close();
        }

        private void ButtonLoginClick(object sender, RoutedEventArgs e)
        {
            if (String.IsNullOrEmpty(loginTextInput.Text) || String.IsNullOrEmpty(passwordTextInput.Password))
            {
                MessageBox.Show("Пожалуйста, заполните оба поля!");
            }
            else
            {
                if (checkLoginRem.IsChecked == true)
                {
                    Manager.LoginRemember = true;
                }
                else
                {
                    Manager.LoginRemember = false;
                }

                Manager.Login = loginTextInput.Text;
                Manager.Password = passwordTextInput.Password;

                ChoseAdminLogin openCheckWindow = new ChoseAdminLogin();
                openCheckWindow.ShowDialog();
            }
        }

        private void ButtonCancelClick(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}