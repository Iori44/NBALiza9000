﻿using NBAManagement.AppData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NBAManagement
{
    /// <summary>
    /// Логика взаимодействия для ManagePlayers.xaml
    /// </summary>
    public partial class ManagePlayers : Window
    {
        public ManagePlayers()
        {
            InitializeComponent();

            List<String> countryList = new List<String>();
            countryList.Add("All countries");
            foreach (var country in BasketballSystemEntities.GetContext().Country)
            {
                countryList.Add(country.CountryName);
            }
            choseCountryList.ItemsSource = countryList;

            List<String> positionList = new List<String>();
            positionList.Add("All positions");
            foreach (var pos in BasketballSystemEntities.GetContext().Position)
            {
                positionList.Add(pos.Name);
            }
            chosePosList.ItemsSource = positionList;

            dateGridPlayers.ItemsSource = BasketballSystemEntities.GetContext().Player.ToList();
            inputTotalPlayers.Text = "Total players: " + BasketballSystemEntities.GetContext().Player.Count();

            int yearToday = DateTime.Now.Year;
            if (yearToday % 2 == 0)
            {
                historyText.Text += yearToday - 1 + "-" + yearToday + "," +
                    " and the NBA already has a history of " + (yearToday - 1946) + " years.";
            }
            else
            {
                historyText.Text += yearToday + "-" + yearToday + 1 + "," +
                    " and the NBA already has a history of " + (yearToday - 1946) + " years.";
            }
        }

        private void ButtonSearchClick(object sender, RoutedEventArgs e)
        {
            var playersList = BasketballSystemEntities.GetContext().Player.ToList();

            if (chosePosList.SelectedIndex > 0)
            {
                playersList = playersList.Where(p => p.PositionId == chosePosList.SelectedIndex).ToList();
            }

            if (choseCountryList.SelectedIndex > 0)
            {
                var countryList = BasketballSystemEntities.GetContext().Country.Where(p => p.CountryName == choseCountryList.SelectedItem.ToString()).First();
                playersList = playersList.Where(p => p.CountryCode == countryList.CountryCode).ToList();
            }

            playersList = playersList.Where(p => p.Name.ToLower().Contains(inputPlayerName.Text.ToLower())).ToList();
            inputTotalPlayers.Text = "Total players: " + playersList.Count();
            dateGridPlayers.ItemsSource = playersList;
        }

        private void ButtonLogoutClick(object sender, RoutedEventArgs e)
        {
            Manager.AutorisationCheck = false;
            Manager.LoginRemember = false;
            Manager.UserRoleId = 0;
            Manager.Login = "";
            Manager.Password = "";
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void ButtonBackClick(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
