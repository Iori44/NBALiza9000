﻿using NBAManagement.AppData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NBAManagement
{
    /// <summary>
    /// Логика взаимодействия для EventAdministratorMenu.xaml
    /// </summary>
    public partial class EventAdministratorMenu : Window
    {
        public EventAdministratorMenu()
        {
            InitializeComponent();

            int yearToday = DateTime.Now.Year;
            if (yearToday % 2 == 0)
            {
                historyText.Text += yearToday - 1 + "-" + yearToday + "," +
                    " and the NBA already has a history of " + (yearToday - 1946) + " years.";
            }
            else
            {
                historyText.Text += yearToday + "-" + yearToday + 1 + "," +
                    " and the NBA already has a history of " + (yearToday - 1946) + " years.";
            }
        }

        private void ButtonLogoutClick(object sender, RoutedEventArgs e)
        {
            Manager.AutorisationCheck = false;
            Manager.LoginRemember = false;
            Manager.UserRoleId = 0;
            Manager.Login = "";
            Manager.Password = "";
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void ButtonBackClick(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void ButtonManageSeasonsClick(object sender, RoutedEventArgs e)
        {
            ManageSeasons manageSeasons = new ManageSeasons();
            manageSeasons.Show();
            this.Close();
        }

        private void ButtonManageMatchupsClick(object sender, RoutedEventArgs e)
        {
            ManageMatchups manageMatchups = new ManageMatchups();
            manageMatchups.Show();
            this.Close();
        }

        private void ButtonManageTeamsClick(object sender, RoutedEventArgs e)
        {
            ManageTeams manageTeams = new ManageTeams();
            manageTeams.Show();
            this.Close();
        }

        private void ButtonManagePlayersClick(object sender, RoutedEventArgs e)
        {
            ManagePlayers managePlayers = new ManagePlayers();
            managePlayers.Show();
            this.Close();
        }
    }
}