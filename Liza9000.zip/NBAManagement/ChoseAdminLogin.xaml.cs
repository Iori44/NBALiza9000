﻿using NBAManagement.AppData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NBAManagement
{
    /// <summary>
    /// Логика взаимодействия для ChoseAdminLogin.xaml
    /// </summary>
    public partial class ChoseAdminLogin : Window
    {
        public ChoseAdminLogin()
        {
            InitializeComponent();
        }

        private void ButtonCloseClick(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void ButtonEventAdminClick(object sender, RoutedEventArgs e)
        {
            var eventAdminLogin = BasketballSystemEntities.GetContext().Admin.Where(p => p.JobNumber == Manager.Login && p.Passwords == Manager.Password
                && p.RoleId == "1").ToList();
            if (eventAdminLogin.Count == 0)
            {
                MessageBox.Show("Неправильно введен логин или пароль!");
            }
            else
            {
                EventAdministratorMenu eventAdministratorMenu = new EventAdministratorMenu();
                eventAdministratorMenu.Show();
                
                Manager.AutorisationCheck = true;
                Manager.UserRoleId = 1;
                Manager.WindowAdminLogin.Close();
                this.Close();
            }
        }

        private void ButtonTechAdminClick(object sender, RoutedEventArgs e)
        {
            var eventAdminLogin = BasketballSystemEntities.GetContext().Admin.Where(p => p.JobNumber == Manager.Login && p.Passwords == Manager.Password
                && p.RoleId == "2").ToList();
            if (eventAdminLogin.Count == 0)
            {
                MessageBox.Show("Неправильно введен логин или пароль!");
            }
            else
            {
                TechnicalAdministratorMenu technicalAdministratorMenu = new TechnicalAdministratorMenu();
                technicalAdministratorMenu.Show();

                Manager.AutorisationCheck = true;
                Manager.UserRoleId = 2;
                Manager.WindowAdminLogin.Close();
                this.Close();
            }
        }
    }
}