﻿using NBAManagement.AppData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NBAManagement
{
    /// <summary>
    /// Логика взаимодействия для TechnicalAdministratorMenu.xaml
    /// </summary>
    public partial class TechnicalAdministratorMenu : Window
    {
        public TechnicalAdministratorMenu()
        {
            InitializeComponent();

            int yearToday = DateTime.Now.Year;
            if (yearToday % 2 == 0)
            {
                historyText.Text += yearToday - 1 + "-" + yearToday + "," +
                    " and the NBA already has a history of " + (yearToday - 1946) + " years.";
            }
            else
            {
                historyText.Text += yearToday + "-" + yearToday + 1 + "," +
                    " and the NBA already has a history of " + (yearToday - 1946) + " years.";
            }
        }

        private void ButtonLogoutClick(object sender, RoutedEventArgs e)
        {
            Manager.AutorisationCheck = false;
            Manager.LoginRemember = false;
            Manager.UserRoleId = 0;
            Manager.Login = "";
            Manager.Password = "";
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void ButtonBackClick(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void ButtonTeamReportClick(object sender, RoutedEventArgs e)
        {
            TeamReport teamReport = new TeamReport();
            teamReport.Show();
            this.Close();
        }

        private void ButtonManageExecClick(object sender, RoutedEventArgs e)
        {

        }
    }
}
