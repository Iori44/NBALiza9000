﻿using NBAManagement.AppData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NBAManagement
{
    /// <summary>
    /// Логика взаимодействия для ManageTeams.xaml
    /// </summary>
    public partial class ManageTeams : Window
    {
        public ManageTeams()
        {
            InitializeComponent();

            dateGridTeams.ItemsSource = BasketballSystemEntities.GetContext().Team.ToList();
            inputTotalTeams.Text = "Total teams: " + BasketballSystemEntities.GetContext().Team.Count().ToString();

            List <String> confList = new List <String>();
            confList.Add("All conferences");
            foreach(var conf in BasketballSystemEntities.GetContext().Conference)
            {
                confList.Add(conf.Name);
            }
            choseConferenceList.ItemsSource = confList;

            List<String> divisonList = new List<String>();
            divisonList.Add("All divisions");
            foreach (var divi in BasketballSystemEntities.GetContext().Division)
            {
                divisonList.Add(divi.Name);
            }
            choseDivisionList.ItemsSource = divisonList;

            int yearToday = DateTime.Now.Year;
            if (yearToday % 2 == 0)
            {
                historyText.Text += yearToday - 1 + "-" + yearToday + "," +
                    " and the NBA already has a history of " + (yearToday - 1946) + " years.";
            }
            else
            {
                historyText.Text += yearToday + "-" + yearToday + 1 + "," +
                    " and the NBA already has a history of " + (yearToday - 1946) + " years.";
            }
        }

        private void ButtonLogoutClick(object sender, RoutedEventArgs e)
        {
            Manager.AutorisationCheck = false;
            Manager.LoginRemember = false;
            Manager.UserRoleId = 0;
            Manager.Login = "";
            Manager.Password = "";
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void ButtonBackClick(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void ButtonSearchClick(object sender, RoutedEventArgs e)
        {
            var teamsList = BasketballSystemEntities.GetContext().Team.ToList();

            if (choseConferenceList.SelectedIndex > 0)
            {
                var checkDivisions = BasketballSystemEntities.GetContext().Division.Where(p => p.DivisionId == choseConferenceList.SelectedIndex).ToList();
                teamsList = teamsList.Where(p => checkDivisions.Any(c => c.DivisionId == p.DivisionId)).ToList();
            }

            if (choseDivisionList.SelectedIndex > 0)
            {
                teamsList = teamsList.Where(p => p.DivisionId == choseDivisionList.SelectedIndex).ToList();
            }

            teamsList = teamsList.Where(p => p.TeamName.ToLower().Contains(inputTeamName.Text.ToLower())).ToList();
            inputTotalTeams.Text = "Total teams: " + teamsList.Count();
            dateGridTeams.ItemsSource = teamsList;
        }
    }
}