﻿using NBAManagement.AppData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NBAManagement
{
    /// <summary>
    /// Логика взаимодействия для TeamDetail.xaml
    /// </summary>
    public partial class TeamDetail : Window
    {
        public TeamDetail(Team targetTeam, int targetItem)
        {
            InitializeComponent();
            Manager.CheckTeam = targetTeam;
            tabTeamPanel.SelectedIndex = targetItem;
            imageTeamPreview.DataContext = targetTeam;
           
            List<string> seasonList = new List<string>();
            seasonList.Add("All Seasons");
            foreach (var seas in BasketballSystemEntities.GetContext().Season)
            {
                seasonList.Add(seas.Name);
            }
            choseYearCheck.ItemsSource = seasonList;
           
            textTeamPreview.Text += "Team " + targetTeam.TeamName + " | Division " + targetTeam.Division.Name + " of " 
                + "Conference " + targetTeam.Division.Conference.Name;
            dateGridRoster.ItemsSource = BasketballSystemEntities.GetContext().PlayerInTeam.Where(p => p.Team.TeamId == targetTeam.TeamId).ToList();
           
            dateGridMatchup.ItemsSource = BasketballSystemEntities.GetContext().Matchup.Where(p => p.Team_Away == targetTeam.TeamId || p.Team_Home == targetTeam.TeamId).ToList();

            int yearToday = DateTime.Now.Year;
            if (yearToday % 2 == 0)
            {
                historyText.Text += yearToday - 1 + "-" + yearToday + "," +
                    " and the NBA already has a history of " + (yearToday - 1946) + " years.";
            }
            else
            {
                historyText.Text += yearToday + "-" + yearToday + 1 + "," +
                    " and the NBA already has a history of " + (yearToday - 1946) + " years.";
            }

            var playersPF = BasketballSystemEntities.GetContext().PlayerInTeam.Where(p => p.TeamId == targetTeam.TeamId).ToList();
            List<string> listPF = new List<string>();
            foreach(var pos in playersPF)
            {
                foreach(var player in BasketballSystemEntities.GetContext().Player)
                {
                    if (player.PlayerId == pos.PlayerId && player.PositionId == 2 && !(listPF.Contains(player.Name)))
                    {
                        listPF.Add(player.Name);
                    }
                }
               
            }
            listBoxPF.ItemsSource = listPF;

            var playersSF = BasketballSystemEntities.GetContext().PlayerInTeam.Where(p => p.TeamId == targetTeam.TeamId).ToList();
            List<string> listSF = new List<string>();
            foreach (var pos in playersSF)
            {
                foreach (var player in BasketballSystemEntities.GetContext().Player)
                {
                    if (player.PlayerId == pos.PlayerId && player.PositionId == 1 && !(listSF.Contains(player.Name)))
                    {
                        listSF.Add(player.Name);
                    }
                }

            }
            listBoxSF.ItemsSource = listSF;

            var playersC = BasketballSystemEntities.GetContext().PlayerInTeam.Where(p => p.TeamId == targetTeam.TeamId).ToList();
            List<string> listC = new List<string>();
            foreach (var pos in playersC)
            {
                foreach (var player in BasketballSystemEntities.GetContext().Player)
                {
                    if (player.PlayerId == pos.PlayerId && player.PositionId == 3 && !(listC.Contains(player.Name)))
                    {
                        listC.Add(player.Name);
                    }
                }

            }
            listBoxC.ItemsSource = listC;

            var playersSG = BasketballSystemEntities.GetContext().PlayerInTeam.Where(p => p.TeamId == targetTeam.TeamId).ToList();
            List<string> listSG = new List<string>();
            foreach (var pos in playersSG)
            {
                foreach (var player in BasketballSystemEntities.GetContext().Player)
                {
                    if (player.PlayerId == pos.PlayerId && player.PositionId == 4 && !(listSG.Contains(player.Name)))
                    {
                        listSG.Add(player.Name);
                    }
                }

            }
            listBoxSG.ItemsSource = listSG;

            var playersPG = BasketballSystemEntities.GetContext().PlayerInTeam.Where(p => p.TeamId == targetTeam.TeamId).ToList();
            List<string> listPG = new List<string>();
            foreach (var pos in playersPG)
            {
                foreach (var player in BasketballSystemEntities.GetContext().Player)
                {
                    if (player.PlayerId == pos.PlayerId && player.PositionId == 5 && !(listPG.Contains(player.Name)))
                    {
                        listPG.Add(player.Name);
                    }
                }

            }
            listBoxPG.ItemsSource = listPG;
        }

        private void ButtonBackClick(object sender, RoutedEventArgs e)
        {
            TeamsMain teamMainChangeWindow = new TeamsMain();
            teamMainChangeWindow.Show();
            this.Close();
        }
        
        private void ButtonSearchYearPeriod(object sender, RoutedEventArgs e)
        {
            var matchupsList = BasketballSystemEntities.GetContext().Matchup.Where(p => p.Team_Away == Manager.CheckTeam.TeamId || p.Team_Home == Manager.CheckTeam.TeamId).ToList();
            if (choseYearCheck.SelectedIndex == 0)
            {
                matchupsList = BasketballSystemEntities.GetContext().Matchup.Where(p => p.Team_Away == Manager.CheckTeam.TeamId || p.Team_Home == Manager.CheckTeam.TeamId).ToList();
            }
            else if (choseYearCheck.SelectedIndex >0)
            {
                matchupsList = matchupsList.Where(p => p.SeasonId == choseYearCheck.SelectedIndex).ToList();
            }
            
            dateGridMatchup.ItemsSource = matchupsList;
        }
    }
}