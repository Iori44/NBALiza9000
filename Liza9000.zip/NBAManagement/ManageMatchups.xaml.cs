﻿using NBAManagement.AppData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NBAManagement
{
    /// <summary>
    /// Логика взаимодействия для ManageMatchups.xaml
    /// </summary>
    public partial class ManageMatchups : Window
    {
        public ManageMatchups()
        {
            InitializeComponent();

            List <string> yearPeriods = new List<string>();
            yearPeriods.Add("All periods");
            foreach(var seas in BasketballSystemEntities.GetContext().Season)
            {
                yearPeriods.Add(seas.Name);
            }
            choseYearCheck.ItemsSource = yearPeriods;

            dateGridPres.ItemsSource = BasketballSystemEntities.GetContext().Matchup.Where(p => p.MatchupTypeId == 0).ToList();
            dateGridRegular.ItemsSource = BasketballSystemEntities.GetContext().Matchup.Where(p => p.MatchupTypeId == 1).ToList();

            int yearToday = DateTime.Now.Year;
            if (yearToday % 2 == 0)
            {
                historyText.Text += yearToday - 1 + "-" + yearToday + "," +
                    " and the NBA already has a history of " + (yearToday - 1946) + " years.";
            }
            else
            {
                historyText.Text += yearToday + "-" + yearToday + 1 + "," +
                    " and the NBA already has a history of " + (yearToday - 1946) + " years.";
            }
        }

        private void ButtonLogoutClick(object sender, RoutedEventArgs e)
        {
            Manager.AutorisationCheck = false;
            Manager.LoginRemember = false;
            Manager.UserRoleId = 0;
            Manager.Login = "";
            Manager.Password = "";
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void ButtonBackClick(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void ButtonUpdateClick(object sender, RoutedEventArgs e)
        {
            Manager.WindowManageMatchups = this;
            AddNewMatchupForRegularSeason addNewMatchupForRegularSeason = new AddNewMatchupForRegularSeason((sender as Button).DataContext as Matchup);
            addNewMatchupForRegularSeason.ShowDialog();
        }

        private void ButtonDeleteClick(object sender, RoutedEventArgs e)
        {
            var matchForRemove = (sender as Button).DataContext as Matchup;
            if (MessageBox.Show($"Вы точно хотите удалить данный элемент?", "Внимание!", 
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    BasketballSystemEntities.GetContext().Matchup.Remove(matchForRemove);
                    BasketballSystemEntities.GetContext().SaveChanges();
                    dateGridPres.ItemsSource = BasketballSystemEntities.GetContext().Matchup.Where(p => p.MatchupTypeId == 0).ToList();
                    dateGridRegular.ItemsSource = BasketballSystemEntities.GetContext().Matchup.Where(p => p.MatchupTypeId == 1).ToList();
                    matchForRemove = null;
                    MessageBox.Show("Данные успешно удалены!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    matchForRemove = null;
                }
            }
            matchForRemove = null;
        }

        private void ButtonSearchYearPeriod(object sender, RoutedEventArgs e)
        {
            var matchupPres = BasketballSystemEntities.GetContext().Matchup.Where(p => p.MatchupTypeId == 0).ToList();
            var matchupRegular = BasketballSystemEntities.GetContext().Matchup.Where(p => p.MatchupTypeId == 1).ToList();

            if (choseYearCheck.SelectedIndex > 0)
            {
                matchupPres = matchupPres.Where(p => p.SeasonId == choseYearCheck.SelectedIndex).ToList();
                matchupRegular = matchupRegular.Where(p => p.SeasonId == choseYearCheck.SelectedIndex).ToList();
            }

            if (dateCheckBox.IsChecked == true)
            {
                matchupPres = matchupPres.Where(p => p.Starttime.Date == datePickerDateCheck.SelectedDate).ToList();
                matchupRegular = matchupRegular.Where(p => p.Starttime.Date == datePickerDateCheck.SelectedDate).ToList();
            }

            dateGridPres.ItemsSource = matchupPres;
            dateGridRegular.ItemsSource = matchupRegular;
        }


        private void ChoseYearCheckSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (choseYearCheck.SelectedIndex == 0)
            {
                datePickerDateCheck.DisplayDateStart = null;
                datePickerDateCheck.DisplayDateEnd = null;
            }
            else if (choseYearCheck.SelectedIndex > 0)
            {
                string firstYear = "";
                string lastYear = "";
                for (int i = 0; i < 4; i++)
                {
                    firstYear = firstYear + Convert.ToString(choseYearCheck.SelectedItem)[i];
                    lastYear = lastYear + Convert.ToString(choseYearCheck.SelectedItem)[i+5];
                }

                DateTime yearOne = new DateTime(Convert.ToInt32(firstYear), 1, 1);
                DateTime yearTwo = new DateTime(Convert.ToInt32(lastYear), 12, 31);

                datePickerDateCheck.DisplayDateStart = Convert.ToDateTime(yearOne);
                datePickerDateCheck.DisplayDateEnd = Convert.ToDateTime(yearTwo);
            }
        }

        private void ButtonAddRegularSeasonClick(object sender, RoutedEventArgs e)
        {
            Manager.WindowManageMatchups = this;
            AddNewMatchupForRegularSeason addNewMatchupForRegularSeason = new AddNewMatchupForRegularSeason(null);
            addNewMatchupForRegularSeason.ShowDialog();
        }

    }
}