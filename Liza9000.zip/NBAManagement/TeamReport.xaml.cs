﻿using NBAManagement.AppData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NBAManagement
{
    /// <summary>
    /// Логика взаимодействия для TeamReport.xaml
    /// </summary>
    public partial class TeamReport : Window
    {
        public TeamReport()
        {
            InitializeComponent();

            var dataList = BasketballSystemEntities.GetContext().PostSeason.ToList();
            dateGridStats.ItemsSource = dataList.OrderBy(p => p.PointsCheck).ToList();

            List <string> matchupTypesList = new List<string>()
            {
                "Preseason",
                "Regular Season",
                "Post Season"
            };
            choseMatchupTypeList.ItemsSource = matchupTypesList;
            choseMatchupTypeList.SelectedIndex = 1;

            List<string> ranksList = new List<string>()
            {
                "Points",
                "Rebounds",
                "Assists",
                "Steals",
                "Blocks"
            };
            choseRankByList.ItemsSource = ranksList;
            choseRankByList.SelectedIndex = 0;

            List<string> checkTotal = new List<string>()
            {
                "Average",
                "Total"
            };
            choseViewByList.ItemsSource = checkTotal;
            choseViewByList.SelectedIndex = 0;

            int yearToday = DateTime.Now.Year;
            if (yearToday % 2 == 0)
            {
                historyText.Text += yearToday - 1 + "-" + yearToday + "," +
                    " and the NBA already has a history of " + (yearToday - 1946) + " years.";
            }
            else
            {
                historyText.Text += yearToday + "-" + yearToday + 1 + "," +
                    " and the NBA already has a history of " + (yearToday - 1946) + " years.";
            }
        }

        private void ButtonLogoutClick(object sender, RoutedEventArgs e)
        {
            Manager.AutorisationCheck = false;
            Manager.LoginRemember = false;
            Manager.UserRoleId = 0;
            Manager.Login = "";
            Manager.Password = "";
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void ButtonBackClick(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void ButtonSearchClick(object sender, RoutedEventArgs e)
        {
            var currentTeamList = BasketballSystemEntities.GetContext().PostSeason.ToList();
            Manager.CurrentMatchupType = choseMatchupTypeList.SelectedItem.ToString();
            if (choseViewByList.SelectedIndex == 0)
            {
                Manager.TotalCheckPoints = false;
            }
            else if (choseViewByList.SelectedIndex == 1)
            {
                Manager.TotalCheckPoints = true;
            }

            switch (choseRankByList.SelectedIndex)
            {
                case 0:
                    currentTeamList = currentTeamList.OrderBy(p => p.PointsCheck).ToList();
                    break;
                case 1:
                    currentTeamList = currentTeamList.OrderBy(p => p.ReboundsCheck).ToList();
                    break;
                case 2:
                    currentTeamList = currentTeamList.OrderBy(p => p.AssistsCheck).ToList();
                    break;
                case 3:
                    currentTeamList = currentTeamList.OrderBy(p => p.StealsCheck).ToList();
                    break;
                case 4:
                    currentTeamList = currentTeamList.OrderBy(p => p.BlocksCheck).ToList();
                    break;
            }

            dateGridStats.ItemsSource = currentTeamList;
        }
    }
}