﻿using NBAManagement.AppData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NBAManagement
{
    /// <summary>
    /// Логика взаимодействия для ManageSeasons.xaml
    /// </summary>
    public partial class ManageSeasons : Window
    {
        public ManageSeasons()
        {
            InitializeComponent();
            dateGridMatchupStats.ItemsSource = BasketballSystemEntities.GetContext().Matchup.ToList();
            dateGridMatchupType.ItemsSource = BasketballSystemEntities.GetContext().Matchup.ToList();

            List <string> seasonList = new List <string>();
            seasonList.Add("All seasons");
            foreach (var season in BasketballSystemEntities.GetContext().Season)
            {
                seasonList.Add(season.Name);
            }
            choseYearCheck.ItemsSource = seasonList;

            List<string> matchupList = new List<string>();
            matchupList.Add("All matchtypes");
            foreach (var matchup in BasketballSystemEntities.GetContext().MatchupType)
            {
                matchupList.Add(matchup.Name);
            }
            choseMatchupTypeCheck.ItemsSource = matchupList;

            int yearToday = DateTime.Now.Year;
            if (yearToday % 2 == 0)
            {
                historyText.Text += yearToday - 1 + "-" + yearToday + "," +
                    " and the NBA already has a history of " + (yearToday - 1946) + " years.";
            }
            else
            {
                historyText.Text += yearToday + "-" + yearToday + 1 + "," +
                    " and the NBA already has a history of " + (yearToday - 1946) + " years.";
            }
        }

        private void ButtonSearchClick(object sender, RoutedEventArgs e)
        {
            var matchupsList = BasketballSystemEntities.GetContext().Matchup.ToList();

            if (choseYearCheck.SelectedIndex > 0)
            {
                matchupsList = matchupsList.Where(p => p.SeasonId == choseYearCheck.SelectedIndex).ToList();
                
            }

            if (choseMatchupTypeCheck.SelectedIndex > 0)
            {
                var matchupTypesList = BasketballSystemEntities.GetContext().MatchupType.Where(p => p.Name == choseMatchupTypeCheck.SelectedItem.ToString()).First();
                matchupsList = matchupsList.Where(p => p.MatchupTypeId == matchupTypesList.MatchupTypeId).ToList();
            }

            dateGridMatchupStats.ItemsSource = matchupsList;
            dateGridMatchupType.ItemsSource = matchupsList;
        }

        private void ButtonLogoutClick(object sender, RoutedEventArgs e)
        {
            Manager.AutorisationCheck = false;
            Manager.LoginRemember = false;
            Manager.UserRoleId = 0;
            Manager.Login = "";
            Manager.Password = "";
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void ButtonBackClick(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}